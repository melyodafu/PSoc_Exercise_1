/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#define MAGIC_ZERO 0 //No further reason as to why there should be a zero it just works and doesn't cause any problems
#define MY_NAME "andreas"
#define START_OF_ASCII_ALPHABET 
#include "project.h"
#include <stdio.h>
int main(void)
{
    CyGlobalIntEnable; /* Enable global interrupts. */

    /* Place your initialization/startup code here (e.g. MyInst_Start()) */
    
    char string[5];
    int buttonPressFlag =0;
    int counterButtonPress = 0;
    int pinReadCycleStart = 0;
    UART_1_Start();
    UART_1_PutCRLF(MAGIC_ZERO);
    UART_1_PutString(MY_NAME);
    UART_1_PutCRLF(MAGIC_ZERO);
    for(;;)
    {
        pinReadCycleStart = pinIn_Read();
        
        ledOutBlue_Write(pinReadCycleStart);
        if(pinReadCycleStart)
        {
           if(!buttonPressFlag)
            {
            counterButtonPress++;
            buttonPressFlag = 1;
            }
        }else
        {
            buttonPressFlag = 0;
        }
        
        if(UART_1_ReadRxStatus()==UART_1_RX_STS_FIFO_NOTEMPTY)
        {
            sprintf(string,"%i",counterButtonPress);
            UART_1_PutString(string);
            UART_1_PutCRLF(MAGIC_ZERO);
            UART_1_ReadRxData();
        }
           
        
        
        
    }
}

/* [] END OF FILE */
