/*******************************************************************************
* File Name: ledOutBlue.h  
* Version 2.20
*
* Description:
*  This file contains Pin function prototypes and register defines
*
* Note:
*
********************************************************************************
* Copyright 2008-2015, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_ledOutBlue_H) /* Pins ledOutBlue_H */
#define CY_PINS_ledOutBlue_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"
#include "ledOutBlue_aliases.h"

/* APIs are not generated for P15[7:6] */
#if !(CY_PSOC5A &&\
	 ledOutBlue__PORT == 15 && ((ledOutBlue__MASK & 0xC0) != 0))


/***************************************
*        Function Prototypes             
***************************************/    

/**
* \addtogroup group_general
* @{
*/
void    ledOutBlue_Write(uint8 value);
void    ledOutBlue_SetDriveMode(uint8 mode);
uint8   ledOutBlue_ReadDataReg(void);
uint8   ledOutBlue_Read(void);
void    ledOutBlue_SetInterruptMode(uint16 position, uint16 mode);
uint8   ledOutBlue_ClearInterrupt(void);
/** @} general */

/***************************************
*           API Constants        
***************************************/
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup driveMode Drive mode constants
     * \brief Constants to be passed as "mode" parameter in the ledOutBlue_SetDriveMode() function.
     *  @{
     */
        #define ledOutBlue_DM_ALG_HIZ         PIN_DM_ALG_HIZ
        #define ledOutBlue_DM_DIG_HIZ         PIN_DM_DIG_HIZ
        #define ledOutBlue_DM_RES_UP          PIN_DM_RES_UP
        #define ledOutBlue_DM_RES_DWN         PIN_DM_RES_DWN
        #define ledOutBlue_DM_OD_LO           PIN_DM_OD_LO
        #define ledOutBlue_DM_OD_HI           PIN_DM_OD_HI
        #define ledOutBlue_DM_STRONG          PIN_DM_STRONG
        #define ledOutBlue_DM_RES_UPDWN       PIN_DM_RES_UPDWN
    /** @} driveMode */
/** @} group_constants */
    
/* Digital Port Constants */
#define ledOutBlue_MASK               ledOutBlue__MASK
#define ledOutBlue_SHIFT              ledOutBlue__SHIFT
#define ledOutBlue_WIDTH              1u

/* Interrupt constants */
#if defined(ledOutBlue__INTSTAT)
/**
* \addtogroup group_constants
* @{
*/
    /** \addtogroup intrMode Interrupt constants
     * \brief Constants to be passed as "mode" parameter in ledOutBlue_SetInterruptMode() function.
     *  @{
     */
        #define ledOutBlue_INTR_NONE      (uint16)(0x0000u)
        #define ledOutBlue_INTR_RISING    (uint16)(0x0001u)
        #define ledOutBlue_INTR_FALLING   (uint16)(0x0002u)
        #define ledOutBlue_INTR_BOTH      (uint16)(0x0003u) 
    /** @} intrMode */
/** @} group_constants */

    #define ledOutBlue_INTR_MASK      (0x01u) 
#endif /* (ledOutBlue__INTSTAT) */


/***************************************
*             Registers        
***************************************/

/* Main Port Registers */
/* Pin State */
#define ledOutBlue_PS                     (* (reg8 *) ledOutBlue__PS)
/* Data Register */
#define ledOutBlue_DR                     (* (reg8 *) ledOutBlue__DR)
/* Port Number */
#define ledOutBlue_PRT_NUM                (* (reg8 *) ledOutBlue__PRT) 
/* Connect to Analog Globals */                                                  
#define ledOutBlue_AG                     (* (reg8 *) ledOutBlue__AG)                       
/* Analog MUX bux enable */
#define ledOutBlue_AMUX                   (* (reg8 *) ledOutBlue__AMUX) 
/* Bidirectional Enable */                                                        
#define ledOutBlue_BIE                    (* (reg8 *) ledOutBlue__BIE)
/* Bit-mask for Aliased Register Access */
#define ledOutBlue_BIT_MASK               (* (reg8 *) ledOutBlue__BIT_MASK)
/* Bypass Enable */
#define ledOutBlue_BYP                    (* (reg8 *) ledOutBlue__BYP)
/* Port wide control signals */                                                   
#define ledOutBlue_CTL                    (* (reg8 *) ledOutBlue__CTL)
/* Drive Modes */
#define ledOutBlue_DM0                    (* (reg8 *) ledOutBlue__DM0) 
#define ledOutBlue_DM1                    (* (reg8 *) ledOutBlue__DM1)
#define ledOutBlue_DM2                    (* (reg8 *) ledOutBlue__DM2) 
/* Input Buffer Disable Override */
#define ledOutBlue_INP_DIS                (* (reg8 *) ledOutBlue__INP_DIS)
/* LCD Common or Segment Drive */
#define ledOutBlue_LCD_COM_SEG            (* (reg8 *) ledOutBlue__LCD_COM_SEG)
/* Enable Segment LCD */
#define ledOutBlue_LCD_EN                 (* (reg8 *) ledOutBlue__LCD_EN)
/* Slew Rate Control */
#define ledOutBlue_SLW                    (* (reg8 *) ledOutBlue__SLW)

/* DSI Port Registers */
/* Global DSI Select Register */
#define ledOutBlue_PRTDSI__CAPS_SEL       (* (reg8 *) ledOutBlue__PRTDSI__CAPS_SEL) 
/* Double Sync Enable */
#define ledOutBlue_PRTDSI__DBL_SYNC_IN    (* (reg8 *) ledOutBlue__PRTDSI__DBL_SYNC_IN) 
/* Output Enable Select Drive Strength */
#define ledOutBlue_PRTDSI__OE_SEL0        (* (reg8 *) ledOutBlue__PRTDSI__OE_SEL0) 
#define ledOutBlue_PRTDSI__OE_SEL1        (* (reg8 *) ledOutBlue__PRTDSI__OE_SEL1) 
/* Port Pin Output Select Registers */
#define ledOutBlue_PRTDSI__OUT_SEL0       (* (reg8 *) ledOutBlue__PRTDSI__OUT_SEL0) 
#define ledOutBlue_PRTDSI__OUT_SEL1       (* (reg8 *) ledOutBlue__PRTDSI__OUT_SEL1) 
/* Sync Output Enable Registers */
#define ledOutBlue_PRTDSI__SYNC_OUT       (* (reg8 *) ledOutBlue__PRTDSI__SYNC_OUT) 

/* SIO registers */
#if defined(ledOutBlue__SIO_CFG)
    #define ledOutBlue_SIO_HYST_EN        (* (reg8 *) ledOutBlue__SIO_HYST_EN)
    #define ledOutBlue_SIO_REG_HIFREQ     (* (reg8 *) ledOutBlue__SIO_REG_HIFREQ)
    #define ledOutBlue_SIO_CFG            (* (reg8 *) ledOutBlue__SIO_CFG)
    #define ledOutBlue_SIO_DIFF           (* (reg8 *) ledOutBlue__SIO_DIFF)
#endif /* (ledOutBlue__SIO_CFG) */

/* Interrupt Registers */
#if defined(ledOutBlue__INTSTAT)
    #define ledOutBlue_INTSTAT            (* (reg8 *) ledOutBlue__INTSTAT)
    #define ledOutBlue_SNAP               (* (reg8 *) ledOutBlue__SNAP)
    
	#define ledOutBlue_0_INTTYPE_REG 		(* (reg8 *) ledOutBlue__0__INTTYPE)
#endif /* (ledOutBlue__INTSTAT) */

#endif /* CY_PSOC5A... */

#endif /*  CY_PINS_ledOutBlue_H */


/* [] END OF FILE */
